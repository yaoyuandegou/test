<template>
  <div class="">

  </div>
</template>

<script>
export default {
  name: 'DetailImageInfo',
  data() { 
    return {

    }
  }
 }
</script>

<style lang="" scoped>
</style>
export const BACK_POSITION = 1000;

export const POP = 'pop';
export const NEW = 'new';
export const SELL = 'sell';
